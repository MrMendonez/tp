$(document).ready(function(){
  
  // initiate modal trigger
  $('.modal-trigger').leanModal();

}); // end document ready function
