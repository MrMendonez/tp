$(document).ready(function(){

  // To initiate side Nav for mobile devices
  $(".button-collapse").sideNav({
    closeOnClick: true
  });

}); // end document ready function
